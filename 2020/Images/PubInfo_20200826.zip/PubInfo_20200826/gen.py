# Created by Satoshi Hasegawa
import pandas as pd
import synthetic as st
import sys
import numpy as np
import secrets

args = sys.argv

if len(args) != 6:
    print("Usage : python [{}] [inputfilename] [header(True or False)] [skipinitialspace(True or False)] [outputfilename] [seed]".format(
        args[0]))
    exit(1)

filename = args[1]
header = 0 if args[2] == "True" else None
skipinitialspace = True if args[3] == "True" else False
outputfilename = args[4]
seed = None if args[5] == "None" else int(args[5])

seed = secrets.randbits(32) if seed is None else seed

np.random.seed(seed)

logcol = []

df = pd.read_csv(filename, header=header,
                 skipinitialspace=skipinitialspace)


sdg = st.SyntheticDataGenerator(
    df=df, scale=False, logcol=logcol, int_kde=True)

# 擬似データの生成
# 1Mレコードの擬似データを作成.
ssf = sdg.generator(1000000)
# 重複レコードを排除.
ssf.drop_duplicates(inplace=True)
# 100Kレコードをサンプリングする.
sampledf = ssf.sample(n=100000, random_state=seed)

print("seed:", seed)
sampledf.to_csv(
    outputfilename, header=False if header is None else True, index=False)
