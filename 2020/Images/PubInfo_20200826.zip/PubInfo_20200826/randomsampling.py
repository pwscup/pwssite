# Created by Satoshi Hasegawa
import pandas as pd
import sys
import numpy as np
import secrets

args = sys.argv

BITS = 32

if len(args) != 8:
    print("Usage : python [{}] [inputfilename] [header(True or False)] [skipinitialspace(True or False)] [ratio] [seed] [outputfilename] [indexfilename]".format(
        args[0]))
    exit(1)

filename = args[1]
header = 0 if args[2] == "True" else None
skipinitialspace = True if args[3] == "True" else False
ratio = float(args[4])
seed = None if args[5] == "None" else int(args[5])
outputfilename = args[6]
indexfilename = args[7]

if 0 >= ratio or ratio >= 1:
    print("a ratio is between 0 and 1.")
    exit(1)

seed = secrets.randbits(BITS) if seed is None else seed

df = pd.read_csv(filename, header=header,
                 skipinitialspace=skipinitialspace)

ratioDf = df.sample(frac=ratio, random_state=seed)

ratioDf.to_csv(
    outputfilename, header=False if header is None else True, index=False)

# 番号も出力
np.savetxt(fname=indexfilename, X=np.array(
    ratioDf.index), delimiter="\n", fmt="%d")

print("seed:", seed)
