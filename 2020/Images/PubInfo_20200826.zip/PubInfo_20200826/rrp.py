# Copyright 2020 Hiroaki Kikuchi 
import pandas as pd
import sys
import random


def rrp(x, q):
    y = [i if random.random() < q else random.choice(x) for i in x]
    return(y)


def rrpdf(df, q, target):
    df2 = df.copy()
    for i in target:
        df2.iloc[:, i] = rrp(df.iloc[:, i].values, q)
    return df2


if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage : python [{}] [samplingfilename] [prob] [outputfilename] [target_columns]".format(
            sys.argv[0]))
        print("Example : python {} aaa.csv 0.9 bbb.csv 0_1_2_3_4_5_6_7_8".format(
            sys.argv[0]))
        exit(-1)

    df = pd.read_csv(sys.argv[1], header=None)
    target = list(set([int(i) for i in sys.argv[4].split("_")]))
    df2 = rrpdf(df, q=float(sys.argv[2]), target=target)
    df2.to_csv(sys.argv[3], header=False, index=False)
