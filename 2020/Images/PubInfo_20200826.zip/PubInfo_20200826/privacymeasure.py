# Created by Satoshi Hasegawa
import numpy as np
import sys

if __name__ == "__main__":
    args = sys.argv

    if len(args) != 3:
        print("Usage : python [{}] [trueindexfilename] [attackindexfilename]".format(
            args[0]))
        exit(1)

    trueindexfilename = args[1]
    attackindexfilename = args[2]

    trueindex = np.loadtxt(trueindexfilename, dtype="int32")
    attackindex = np.loadtxt(attackindexfilename, dtype="int32")
    last = 100
    print(len(np.intersect1d(trueindex, attackindex[0:last]))/last)
