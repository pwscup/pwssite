# Created by Satoshi Hasegawa
# utility functions
import pandas as pd
import numpy as np
import category_encoders as ce
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import f1_score
import sklearn.preprocessing as sp
from sklearn.model_selection import ParameterGrid
import functools

import sys

l1norm = functools.partial(np.linalg.norm, ord=1)


class Utility():

    def __init__(self, dfA, dfB, dfC):
        self.dfA = dfA
        self.dfB = dfB
        self.dfC = dfC

    def decisionTreeClassifier(self, xindexes, yindex, depth, onelabel=None):
        return self.__mlperformance__(xindexes, yindex, sp.OneHotEncoder(drop="first", sparse=False), sp.OrdinalEncoder(), DecisionTreeClassifier(), DecisionTreeClassifier(), f1_score, {"max_depth": [depth], "random_state": [0]}, onelabel=onelabel)

    def __mlperformance__(self, xindexes, yindex, xEncode, yEncode, dfA_model, dfB_model, metrics, tuning_param, onelabel=None):
        # dummy 変数化をし,予測を実行する.
        dfA_x = self.dfA[xindexes]
        dfA_y = self.dfA[[yindex]]
        if onelabel is not None:
            dfA_y = pd.DataFrame(np.where(dfA_y == onelabel, "Y", "N"))

        dfB_x = self.dfB[xindexes]
        dfB_y = self.dfB[[yindex]]
        if onelabel is not None:
            dfB_y = pd.DataFrame(np.where(dfB_y == onelabel, "Y", "N"))

        dfC_x = self.dfC[xindexes]
        dfC_y = self.dfC[[yindex]]
        if onelabel is not None:
            dfC_y = pd.DataFrame(np.where(dfC_y == onelabel, "Y", "N"))

        categories_indexes = list(np.where(dfA_x.dtypes == "object")[0])
        numerics_indexes = list(np.where(dfA_x.dtypes != "object")[0])
        categories = []
        numerics = []
        for i in categories_indexes:
            categories.append(dfA_x.columns[i])
        for i in numerics_indexes:
            numerics.append(dfA_x.columns[i])

        encX = xEncode
        encY = yEncode

        encX.fit(
            pd.concat([dfA_x[categories], dfB_x[categories], dfC_x[categories]], ignore_index=True))
        if yEncode is not None:
            encY.fit(pd.concat([dfA_y, dfB_y, dfC_y], ignore_index=True))

        d_dfA_x = np.hstack(
            [dfA_x[numerics].values, encX.transform(dfA_x[categories])])
        d_dfB_x = np.hstack(
            [dfB_x[numerics].values, encX.transform(dfB_x[categories])])
        d_dfC_A_x = np.hstack(
            [dfC_x[numerics].values, encX.transform(dfC_x[categories])])
        d_dfC_B_x = np.hstack(
            [dfC_x[numerics].values, encX.transform(dfC_x[categories])])

        d_dfA_y = dfA_y if encY is None else encY.transform(dfA_y)
        d_dfB_y = dfB_y if encY is None else encY.transform(dfB_y)

        param = list(ParameterGrid(tuning_param))[0]
        dfA_model.set_params(**param)
        dfA_model.fit(d_dfA_x, d_dfA_y)
        dfB_model.set_params(**param)
        dfB_model.fit(d_dfB_x, d_dfB_y)

        dfA_predicted = dfA_model.predict(d_dfC_A_x)
        dfB_predicted = dfB_model.predict(d_dfC_B_x)

        return metrics(dfA_predicted, dfB_predicted)

    # indexには何属性目を計算するかを与える.
    def count(self, index, normalize=False, normfunc=l1norm):
        dfACol = self.dfA[index]
        dfBCol = self.dfB[index]
        dfACol = dfACol if dfACol.dtype != float else dfACol.astype(
            "int")  # 小数は整数化する
        dfBCol = dfBCol if dfBCol.dtype != float else dfBCol.astype(
            "int")  # 小数は整数化する
        dfAValues = dfACol.value_counts(normalize=normalize)
        dfBValues = dfBCol.value_counts(normalize=normalize)
        dfAValueSet = set(dfAValues.index)
        dfBValueSet = set(dfBValues.index)
        valIndex = dfAValueSet | dfBValueSet
        vec = list()
        for i in valIndex:
            a = 0 if i not in dfAValueSet else dfAValues[i]
            b = 0 if i not in dfBValueSet else dfBValues[i]
            vec.append(a - b)
        return normfunc(np.array(vec))

    def counts(self, normalize=False, normfunc=l1norm):
        col = self.dfA.shape[1]
        n = self.dfA.shape[0]
        s = 0
        for i in range(col):
            s = s + self.count(i, normalize, normfunc)

        return 1 - s/((2*n)*col)

    # 共分散の結果.
    def cov(self, normalize=False, covOnly=True, aggregate=l1norm):
        categories = list(np.where(self.dfA.dtypes == "object")[0])
        enc = ce.OneHotEncoder(cols=categories, drop_invariant=False)
        enc.fit(pd.concat([self.dfA, self.dfB], ignore_index=True))
        dfA_value = enc.transform(self.dfA).astype("float64").values
        dfB_value = enc.transform(self.dfB).astype("float64").values
        if not normalize:
            diff = np.cov(dfA_value.T) - np.cov(dfB_value.T)
        else:
            diff = np.corrcoef(dfA_value.T) - np.corrcoef(dfB_value.T)
        if covOnly:
            diff = diff * (np.ones(diff.shape) - np.eye(N=diff.shape[0]))
        else:
            raise RuntimeError("Not supported")
        val = aggregate(diff/2)
        if val == 0:
            return float("inf")
        return 1/val


if __name__ == "__main__":
    args = sys.argv

    if len(args) != 6:
        print("Usage : python [{}] [samplingfilename] [anonymizefilename] [testfilename] [header(True or False)] [skipinitialspace(True or False)]".format(
            args[0]))
        exit(1)

    samplingfilename = args[1]
    anonymizefilename = args[2]
    testfilename = args[3]
    header = 0 if args[4] == "True" else None
    skipinitialspace = True if args[5] == "True" else False

    dfA = pd.read_csv(samplingfilename, header=header,
                      skipinitialspace=skipinitialspace)

    dfB = pd.read_csv(anonymizefilename, header=header,
                      skipinitialspace=skipinitialspace)

    dfC = pd.read_csv(testfilename, header=header,
                      skipinitialspace=skipinitialspace)

    utility = Utility(dfA, dfB, dfC)

    counts = utility.counts()
    cov = utility.cov()
    resultIncome = utility.decisionTreeClassifier(
        [0, 1, 2, 3, 4, 5, 6, 7], 8, 5, "<=50K")
    resultRelationship = utility.decisionTreeClassifier(
        [0, 1, 2, 3, 4, 6, 7, 8], 5, 3, "Husband")
    print(counts, cov, resultIncome, resultRelationship)
