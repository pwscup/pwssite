# Copyright 2020 Hiroaki Kikuchi 
import pandas as pd
import sys


def kanony(df, qi=[1, 2], k=1):
    return df.groupby(qi).filter(lambda x: x[0].count() >= k)


if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage : python [{}] [samplingfilename] [k] [outputfilename] [target_columns]".format(
            sys.argv[0]))
        print("Example : python {} aaa.csv 2 bbb.csv 0_2_6".format(
            sys.argv[0]))
        exit(-1)
    df = pd.read_csv(sys.argv[1], header=None)
    k = int(sys.argv[2])
    qi = list(set([int(i) for i in sys.argv[4].split("_")]))
    df2 = kanony(df, qi=qi, k=k)
    df2.to_csv(sys.argv[3], header=False, index=False)
