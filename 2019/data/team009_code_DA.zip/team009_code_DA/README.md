# Anonymization Methods
## Usage
example:
```
python do_process.py --teamid 023 --kakouno 01 --datano 01
```

args:
- `teamid`: team ID of input file (orgtraces) (default: 023)
- `kakouno`: type of anonymization method (01 or 02. default: 01)
    - method No.01: shuffling locations in morning times and clustering
    - method No.02: clustering and replacing hospital region (<- the winning algorithm against Trace Inference)
- `datano`: dataset number (01(IDP) or 02(TRP). default: 01)

## Description of each file
- do_process.py: main script
- constant.py: defining the number of users and days
- input_data
    - orgtraces: original traces file
        - orgtraces_team023_data01_IDP.csv: sample file
    - other
		- info_region.csv: location info file given by admin
		- time_weight_023_01.csv: defining importance weights of each timestamp. used in computing weighted count vector
	    - hospital_from_to.csv: defining how to replace the hospital regioin (hospital_from_id -> hospital_to_id). used in method No.02
	- shuffling
		- shuffling_list_team023_data01_IDP.csv: defining the timestamps to shuffle locations (these values are supposed to correspond to morning time). used in method No.01
- output_data: processsed files are output to this folder
- common: computing modules called by do_process.py
- process: computing modules called by do_process.py

## Note
All of the above files are for preliminary round.
To process final round data, following changes are needed.
- put final round data in "input_data" folder
- change `TIME` in constant.py: 40 -> 4000
- extend the index of time_weight_XXX_XX.csv: 1-40 -> 1-4000
- add timestamps to shuffling_list_teamXXX_dataXX_XXX.csv to cover all morning times: 1,2,21,22,41,42,61,62,...3981,3982
