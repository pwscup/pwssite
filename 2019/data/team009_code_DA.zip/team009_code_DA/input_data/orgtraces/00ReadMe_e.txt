## About the dataset
The location data below this directory is newly created based on the SNS-based People Flow Data ( https://nightley.jp/archives/1954/ ).
For more details, please see: PWS Cup 2019 Data Set ( https://www.iwsec.org/pws/2019/cup19-dataset-e.pdf ).

Attribute work to name in the SNS-based People Flow Data is as follows:

[Attribute work to name]
Nightley, Inc.
Shibasaki & Sekimoto Laboratory, the University of Tokyo
Micro Geo Data Forum
People Flow project
Center for Spatial Information Science at the University of Tokyo
