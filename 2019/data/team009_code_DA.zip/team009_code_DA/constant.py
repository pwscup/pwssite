# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 15:40:06 2019
定数格納
@author: c-matsufuji
"""

ALL_USER = 2000
USER = 2000
TIME = 40
