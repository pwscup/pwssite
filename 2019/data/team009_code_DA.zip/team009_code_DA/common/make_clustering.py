# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 11:45:24 2019

@author: c-matsufuji
"""
import numpy as np
import common.calc_distance as calc_distance
import copy
from tqdm import trange

def kmeans(k, dist ,max_iter=50):
    dist_size,row_size,col_size = np.shape(dist)
    # ランダムに重心の初期値を初期化
    centroids  = dist[np.random.choice(dist_size,k)]
    
    # 前の重心と比較するために、仮に新しい重心を入れておく配列を用意
    new_centroids = np.zeros((k, row_size,col_size))
    
    # 各データ所属クラスタ情報を保存する配列を用意
    cluster = np.zeros(dist_size)
    
    # ループ上限回数まで繰り返し
    for epoch in trange(max_iter):       
        # 入力データ全てに対して繰り返し
        for i in range(dist_size):
            distances = np.zeros(k)
            
            # データから各重心までの距離を計算（ルートを取らなくても大小関係は変わらないので省略）
            for j in range(k):
                distances[j]+=calc_distance.pNorm_distance(dist[i],centroids[j],1)
            # データの所属クラスタを距離の一番近い重心を持つものに更新
            cluster[i] = np.argmin(distances)
            
        # すべてのクラスタに対して重心を再計算
        for i in range(k):
            #temp=np.zeros((row_size,col_size))
            if len(cluster[cluster==i])==0:
                new_centroids[i]=dist[np.random.choice(dist_size,1)]
            else:
                new_centroids[i]=np.mean(dist[cluster==i],axis=0)
                
            """
            for j in range(len(dist[cluster==i])):
                temp+=np.array(list(map(lambda p:dec2[p],X[cluster==j][k1])))
            temp=np.round(temp/len(X[cluster==j]))
            
            for k1 in range(40):
                new_centroids[j][k1] = [l for l, v in dec2.items() if v == temp[k1].tolist()][0]
            """
        # もしも重心が変わっていなかったら終了
        if (new_centroids == centroids).all():
            break
        centroids =  copy.copy(new_centroids)
    return cluster
