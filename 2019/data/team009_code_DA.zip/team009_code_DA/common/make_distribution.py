﻿# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 14:47:19 2019

@author: c-matsufuji
"""

import common.MakeDistribution2 as MakeDistribution2
import numpy as np

import constant


#ユーザ数
#NUMBER_OF_USER = 2000
NUMBER_OF_USER = constant.ALL_USER
#タイム数
#NUMBER_OF_TIME = 400
NUMBER_OF_TIME = constant.TIME


def make_distributions_02(data,weight):
    result = np.zeros((NUMBER_OF_USER,32,32))
    for i in range(NUMBER_OF_USER):
        dist01 = MakeDistribution2.make_destribution(data[i],weight, 1)
        #dist02 = mesh.filter_distribution_y(dist01, 1)
        result[i] = dist01
    return result