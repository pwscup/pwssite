# -*- coding: utf-8 -*-
"""
Created on Thu Sep 26 10:02:55 2019
距離関数まとめ
@author: c-matsufuji
"""
import numpy as np
import math
"""
x,yはndarray->shape()

"""
def _norm(x):
    return math.sqrt(x[0] ** 2 + x[1] ** 2)

def euclidian_sum_distance(x,y):
    #return np.sum([np.linalg.norm(x[i]-y[i]) for i in range(len(x))])
    return np.sum([_norm(x[i]-y[i]) for i in range(len(x))])

def weighted_euclidian_sum_distance(x,y,time_weight_list):
    """
    重み付き距離
    """
    return np.sum([_norm(x[i]-y[i]) * time_weight_list[i] for i in range(len(x))])

def pNorm_distance(A,B,p):
    if(p==0):
        return -1
    a = np.array(A)
    b = np.array(B)
    row,col = np.shape(a)
    if (row,col) != np.shape(b):
        return -1
    return np.sum(np.abs(a-b)**p)**(1/p)

def KL_distance(A,B):
    a = np.array(A)
    b = np.array(B)
    if len(b[b==0])>0:
        return -1
    row,col = np.shape(a)
    if (row,col) != np.shape(b):
        return -1
    return np.sum(a*np.log(a/b))
