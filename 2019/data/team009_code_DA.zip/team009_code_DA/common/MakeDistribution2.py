import numpy as np
import pandas as pd
import copy as cp

filePath_reg = ".//input_data//other//info_region.csv"
reg0 = pd.read_csv(filePath_reg)
region_file = np.array(reg0)

# Smallest probability
Delta = 1e-8

def make_destribution(trace,list,prm):
    """
    トレースファイルと重みリストから、パラメータで指定された手法で滞在分布行列をreturnする
    ＊info_region.csvを実行ディレクトリ直下に置く必要あり
    :parameter
    --------------------------------------------------------------
    trace
        滞在分布を作成するユーザのトレース（加工・参照は問わない）　40行分のデータ
        type:np.array
    list
        時間毎に重みを指定した配列　1024行分のデータ
        type:np.array
    prm
        加工手法を指定するパラメータ
        type:int
        予備選は1を指定
    --------------------------------------------------------------
    """
    if prm==1:
        #一般化されたregion_id⇒重心に変換
        #一部削除されている⇒前後のregion_idから線形でいい感じの値をとる
        #全部削除されている⇒全部region_id=0とする
        #region_idが1つの場合⇒そのまま
        #0 < region_id <= 1024に収まらないものがある⇒0か1024にする

        _trace=cp.deepcopy(trace)

        for lst in _trace:
            reg_id_lst = str(lst).split(" ")
            reg_id_num = len(reg_id_lst)
            if reg_id_num == 1 and reg_id_lst[0] != "*":
                #要素が一個且つ削除されていなければ何もしない
                pass
            elif reg_id_num >= 2:
                lst=toCenter(reg_id_lst,reg_id_num).astype(str)

            elif reg_id_lst[0] == "*":
                #あとでなおす
                lst='1'
    elif prm==2:
        pass

    #ここから滞在分布行列を作成ロジック
    logpost=np.zeros((32,32))
    total_point=0

    for line_count,lst in enumerate(_trace):
        logx=toX(lst)-1
        logy=toY(lst)-1
        #時間の重み付け

        point=list[line_count]

        total_point=total_point + point
        #配列の左したが領域ID:1になるように補正が必要。あとでやる。
        logpost[logx,logy] = logpost[logx,logy] + point

    logpost=logpost / total_point + Delta

    return logpost

#重心の領域IDを返す
#範囲外のものは0を返す
def toCenter(reg_id_lst,reg_id_num):
    reg_data=read_regionFILE()
    # 一般化されていたら重心をとる
    reg_id = reg_id_lst
    # 重心の座標初期化
    gx = 0
    gy = 0
    # あとでロジックなおす(座標の平均値なので重心とはちょっと違う)
    for reg in reg_id:
        gx = gx + toX(reg)
        gy = gy + toY(reg)
    gx = round(gx / reg_id_num).astype(int)
    gy = round(gy / reg_id_num).astype(int)

    #inf_region.csvから領域IDを抜き出す
    for reg in reg_data:
        if reg[2] == gx and reg[1] == gy:
            return reg[0].astype(int)
    return 0

def read_regionFILE():
    return region_file

#領域IDからx座標を返す
def toX(reg_id):
    reg_data = read_regionFILE()
    return reg_data[int(reg_id) - 1][2].astype(int)

#領域IDからy座標を返す
def toY(reg_id):
    reg_data = read_regionFILE()
    return reg_data[int(reg_id) - 1][1].astype(int)
"""
if __name__ == '__main__':
    filePath_data = "sample.csv"
    filePath_list = "list.csv"
    data0 = pd.read_csv(filePath_data)
    data1 = np.array(data0)
    data2 = pd.read_csv(filePath_list)
    data3 = np.array(data2["weight"])
    print(make_destribution(data1,data3,1))
"""