﻿# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 02:56:00 2019
ファイル出力用関数類

@author: c-matsufuji
"""
import csv
import numpy as np

import constant


#ユーザ数
#NUMBER_OF_USER = 2000
NUMBER_OF_USER = constant.ALL_USER
#タイム数
#NUMBER_OF_TIME = 400
NUMBER_OF_TIME = constant.TIME

def file_writer(data,file_path):
    with open(file_path, 'w',newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['reg_id'])
        for var in np.reshape(data,(NUMBER_OF_USER*NUMBER_OF_TIME,1)):
            writer.writerow([int(var)])
            
def file_writer_distributions(data,file_path):
    with open(file_path, 'w',newline='') as f:
        writer = csv.writer(f)
        for user in data:
            for user_row in user:
                writer.writerow(user_row)
            writer.writerow('')
            
def file_writer_sorted_user(data,file_path):
    with open(file_path, 'w',newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['user_index'])
        for var in data:
            writer.writerow([var])
            
def file_writer_hospital(data,file_path):
    with open(file_path, 'w',newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['hospital_from_id','hospital_to_id'])
        for i in range(len(data)):
            print([data[i],data[(i+2)%len(data)]])
            writer.writerow([data[i],data[(i+2)%len(data)]])
def file_writer_cluster(data,file_path):
    with open(file_path, 'w',newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['cluster_id'])
        for i in range(len(data)):
            writer.writerow([data[i]])
        
