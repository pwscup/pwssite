﻿# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 01:45:34 2019
ファイル読み込み用関数類
@author: c-matsufuji
"""
import numpy as np
import pandas as pd
import constant

#import file_writer

#ユーザ数
#NUMBER_OF_USER = 2000
NUMBER_OF_USER = constant.ALL_USER
#タイム数
#NUMBER_OF_TIME = 400
NUMBER_OF_TIME = constant.TIME
#領域滞在分布の行数
REGION_ROW_SIZE = 32

#領域滞在分布の列数
REGION_COL_SIZE = 32

"""
file_reader_orgtraces:
    元データのCSVを読み込みarraylistを返す
    input:file_path(元データのファイルパス)
    output:np.array(shape(NUMBER_OF_USERS,NUMBER_OF_TIME))のユーザの位置情報を格納したリスト
"""

def file_reader_orgtraces(file_path):
    data0 = pd.read_csv(file_path)
    return np.reshape(np.array(data0['reg_id']),(NUMBER_OF_USER,NUMBER_OF_TIME))

def file_reader_weight(file_path):
    data0 = pd.read_csv(file_path)
    return np.array(data0['weight'])

def file_reader_shuffling(file_path):
    data0 = pd.read_csv(file_path)
    return np.array(data0['time_id'])

def file_reader_user_distance(file_path):
    data0 = pd.read_csv(file_path)
    return np.array(data0['user_index'])

def file_reader_region_hospital(file_path):
    data0 = pd.read_csv(file_path)
    return [data0['reg_id'][i] for i in range(len(data0)) if data0['hospital'][i]==1]


def file_reader_hospital_from_to(file_path):
    data0 = pd.read_csv(file_path)
    return np.array([[data0['hospital_from_id'][i],data0['hospital_to_id'][i]] for i in range(len(data0))])

def file_reader_cluster(file_path):
    data0 = pd.read_csv(file_path)
    return np.array(data0['cluster_id'])


#file_writer.file_writer_hospital(file_reader_region_hospital("..//input_data//other//info_region.csv"),"hospital_from_to.csv")
#print(file_reader_region_hospital("..//input_data//other//info_region.csv"))
"""
file_reader_distributions:
    滞在領域分布が格納されたCSVを読み込みarraylistを返す
    input:file_path(ユーザーの滞在領域分布が格納されたファイルのパス)
    output:np.array(shape(NUMBER_OF_USERS,REGION_ROW_SIZE,REGION_COL_SIZE))の領域滞在分布リスト
    
"""
def file_reader_distributions(file_path):
    data0 = np.array(pd.read_csv(file_path,header=None))
    return np.reshape(data0,(2000,32,32))

def file_reader_distributions2(file_path):
    data0 = np.array(pd.read_csv(file_path,header=None,dtype='float64'))
    return np.reshape(data0,(2000,32,32))