﻿# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 13:49:10 2019

@author: c-matsufuji
"""
import common.file_reader as file_reader
import common.file_writer as file_writer
import common.make_distribution as make_distribution
import common.make_clustering as make_clustering
import process.process_shuffling as process_shuffling
import process.process_nanigasi as process_nanigasi
import os
import sys
import argparse
import datetime

# ID推定対策用加工
def process_Id(team_id,data_no):
    os.mkdir('output_data/anotraces')
    file_name_input=''
    file_name_output=''
    if data_no == 1:
        file_name_input='orgtraces_team%03d_data%02d_IDP'%(team_id,data_no)
        file_name_output='anotraces_team%03d_data%02d_IDP'%(team_id,data_no)
        file_name_shuffle='shuffling_list_team%03d_data%02d_IDP'%(team_id,data_no)
        file_name_weight='time_weight_%03d_%02d'%(team_id,data_no)
    elif data_no == 2:
        file_name_input='orgtraces_team%03d_data%02d_TRP'%(team_id,data_no)
        file_name_output='anotraces_team%03d_data%02d_TRP'%(team_id,data_no)
        file_name_shuffle='shuffling_list_team%03d_data%02d_TRP'%(team_id,data_no)
        file_name_weight='time_weight_%03d_%02d'%(team_id,data_no)
    input_path = 'input_data//orgtraces//'+file_name_input+'.csv'
    output_path = 'output_data//anotraces//'+file_name_output+'.csv'
    weight_path = 'input_data//other//'+file_name_weight+'.csv'
    weight = file_reader.file_reader_weight(weight_path)
    data = file_reader.file_reader_orgtraces(input_path)
    org_distributions = make_distribution.make_distributions_02(data,weight)
    cluster = make_clustering.kmeans(100,org_distributions)

    shuffling_list = file_reader.file_reader_shuffling('input_data//shuffling//'+file_name_shuffle+'.csv')
    next_data=process_shuffling.process_shuffling_01(data,shuffling_list)
    distributions = make_distribution.make_distributions_02(next_data,weight)
    file_writer.file_writer(process_nanigasi.process_mean_02(next_data,data,distributions,org_distributions,cluster),output_path)
    os.rename('output_data//anotraces', 'output_data//anotraces_'+datetime.datetime.now().strftime('%Y%m%d%H%M')) 
    
# トレース推定対策用加工

def process_Trace(team_id,data_no):
    os.mkdir('output_data/anotraces')
    file_name_input=''
    file_name_output=''
    if data_no == 1:
        file_name_input='orgtraces_team%03d_data%02d_IDP'%(team_id,data_no)
        file_name_output='anotraces_team%03d_data%02d_IDP'%(team_id,data_no) 
        file_name_weight='time_weight_%03d_%02d'%(team_id,data_no)
    elif data_no == 2:
        file_name_input='orgtraces_team%03d_data%02d_TRP'%(team_id,data_no)
        file_name_output='anotraces_team%03d_data%02d_TRP'%(team_id,data_no)
        file_name_weight='time_weight_%03d_%02d'%(team_id,data_no)
    input_path = 'input_data//orgtraces//'+file_name_input+'.csv'
    output_path = 'output_data//anotraces//'+file_name_output+'.csv'
    weight_path = 'input_data//other//'+file_name_weight+'.csv'
    weight = file_reader.file_reader_weight(weight_path)
    file_name_hospital='hospital_from_to'
    hospital_path = 'input_data//other//'+file_name_hospital+'.csv'
    hospital_from_to = file_reader.file_reader_hospital_from_to(hospital_path)
    data = file_reader.file_reader_orgtraces(input_path)
    distributions = make_distribution.make_distributions_02(data,weight)
    cluster = make_clustering.kmeans(100,distributions)
    if data_no == 1:
        next_data=process_nanigasi.process_mean_03(data,distributions,cluster,0.745) 
    else:
        next_data=process_nanigasi.process_mean_03(data,distributions,cluster,0.745) 
    file_writer.file_writer(process_shuffling.process_shuffling_03(data,next_data,hospital_from_to),output_path)
    os.rename('output_data//anotraces', 'output_data//anotraces_'+datetime.datetime.now().strftime('%Y%m%d%H%M')) 
    return 0

parser = argparse.ArgumentParser(description="make id process")
parser.add_argument("--teamid", default="023")
parser.add_argument("--kakouno", default="01")
parser.add_argument("--datano", default="01")

args = parser.parse_args()

team_id = int(args.teamid)
data_no = int(args.datano)
kakou_no = int(args.kakouno)

try:
    if kakou_no == 1:
        process_Id(team_id,data_no)
    elif kakou_no == 2:
        process_Trace(team_id,data_no)
    else:
        kakou_function = getattr(sys.modules[__name__], f'process{kakou_no:0>2}')
        kakou_function(team_id, data_no)
except Exception as e:
    print(e)
    if os.path.isdir('output_data//anotraces'):
        os.rename('output_data//anotraces', 'output_data//anotraces_failed'+datetime.datetime.now().strftime('%Y%m%d%H%M')) 