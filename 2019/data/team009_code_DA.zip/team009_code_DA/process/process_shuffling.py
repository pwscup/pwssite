# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 02:21:23 2019

Shuffle Process

@author: c-matsufuji
"""
import random
import copy
import numpy as np
from tqdm import trange
"""
process_shuffling_01:
    与えられたデータの指定された一部をランダムに並び替える
    input:data(N*Mのリスト)
          shuffl_list(シャッフルする列を指定するリスト)
    output:shuffl_listで指定されたm列を行でシャッフルしたリスト
"""
def process_shuffling_01(data,shuffl_list):
    data0 = copy.copy(data)
    for index in shuffl_list:
        random.shuffle(data0[:,index-1])
    return data0


def process_shuffling_02(data,shuffl_hospital_list):
    data0 = np.array([])
    for i in trange(len(data)):
        for j in range(len(data[i])):
            var = data[i,j]
            if var in shuffl_hospital_list[:,0]:        
                hospital_index=np.where(shuffl_hospital_list[:,0]==var)[0]
                var = shuffl_hospital_list[hospital_index[0],1]
            data0 = np.append(data0,var)
    return data0


def process_shuffling_03(org_data,pro_data,shuffl_hospital_list):
    data0 = np.array([])
    for i in trange(len(org_data)):
        for j in range(len(org_data[i])):
            var = org_data[i,j]
            if var in shuffl_hospital_list[:,0]:        
                #print("OK")
                hospital_index=np.where(shuffl_hospital_list[:,0]==var)[0]
                var = shuffl_hospital_list[hospital_index[0],1]
            else:
                var = pro_data[i,j]
            data0 = np.append(data0,var)
    return data0