
XY_MAX = 31
# XY_MAX = 2


def otani_method2(distribution_steps_list, avg_distribution_steps, target_x, target_y):
    """

    size:クラスターA内のユーザ数
    in -> ndarray shape:(size,32,32) ,  ndarray shape:(32,32) (平均滞在ステップ数) , x , y  (x,y：インデックス)
    out -> [{((x',y'),(x'',y'')) : num},...]  (リストのサイズ数:size , x',y'からx'',y''にnum移す)

    :param distribution_steps_list:
    :param avg_distribution_steps:
    :param target_x:
    :param target_y:
    :return:
    """
    result = []
    for distribution_steps in distribution_steps_list:
        avg_step = avg_distribution_steps[target_x, target_y]
        target_step = distribution_steps[target_x, target_y]
        step_diff = target_step - avg_step
        if step_diff != 0:
            shift_vectors = _get_shift_vectors(target_x, target_y, step_diff,
                                               avg_distribution_steps, distribution_steps)
        else:
            shift_vectors = {}
        result.append(shift_vectors)
    return result


def _get_shift_vectors(x, y, step_diff, avg_distribution_steps, distribution_steps):
    """
    1人分の移動情報を計算
    :param x:
    :param y:
    :param step_diff:
    :param avg_distribution_steps:
    :param distribution_steps:
    :return: {((x',y'),(x'',y'')) : num} x',y'からx'',y''にnum移す
    """
    shift_vectors = {}
    points = _point_generator(x, y)

    for p in points:
        if step_diff == 0:
            break
        margin = distribution_steps[p] - avg_distribution_steps[p]
        if step_diff * margin < 0:
            if step_diff > 0:
                shift_steps = min(step_diff, -margin)
                shift_vectors[((x, y), p)] = shift_steps
                step_diff = step_diff - shift_steps
            else:
                shift_steps = min(-step_diff, margin)
                shift_vectors[(p, (x, y))] = shift_steps
                step_diff = step_diff + shift_steps
    return shift_vectors


def _make_distance_order_point_list(d):
    """
    (0, 0)を基準点として整数の座標をマンハッタン距離が近い順に並べたリストを返す
    :param d: 最大のマンハッタン距離
    :return:
    """
    distance_point_list = [[] for _ in range(d+1)]
    point_list = []
    for dx in range(-d, d + 1):
        for dy in range(abs(dx) - d, -abs(dx) + d + 1):
            distance_point_list[abs(dx) + abs(dy)].append((dx, dy))
    for d in distance_point_list:
        point_list.extend(d)
    return point_list


_distance_order_point_list = _make_distance_order_point_list(XY_MAX * 2)


def _point_generator(x, y):
    """
    (x, y)を基準点として整数の座標をマンハッタン距離が近い順に返すジェネレータ
    :param x:
    :param y:
    :return:
    """
    point_list = _distance_order_point_list
    for p in point_list:
        xx = x + p[0]
        yy = y + p[1]
        if 0 <= xx <= XY_MAX and 0 <= yy <= XY_MAX:
            yield (xx, yy)


# # debug (XY_MAX = 2)
# import numpy as np
# distribution_steps_list = np.array([
#     [[0, 2, 2], [0, 8, 1], [0, 0, 0]],
#     [[0, 0, 0], [0, 2, 3], [0, 0, 4]]
# ])
# avg_distribution_steps = np.array(
#     [[0, 1, 1], [0, 5, 2], [0, 0, 2]],
# )
# r = otani_method2(distribution_steps_list, avg_distribution_steps, 1, 1)
# print(r)
