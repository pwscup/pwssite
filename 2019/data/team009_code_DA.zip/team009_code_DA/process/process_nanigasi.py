﻿# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 11:10:24 2019

@author: c-matsufuji
"""
import numpy as np
import copy
from tqdm import trange
import process.otani_method2 as otani_method2
import math
import constant

X_SIZE = 32
Y_SIZE = 32
SIZE = 32
#NUMBER_OF_TIME = 4
NUMBER_OF_TIME = constant.TIME
#TIME = 10
def process_make_step_matrix(distribution):
    return np.round(distribution*NUMBER_OF_TIME)

def process_make_mean_step_matrix(step_matrixes):
    return np.round(np.mean(step_matrixes,axis=0))

def process_sort_index(step_matrix):
    return np.array([[int(v/X_SIZE),v%Y_SIZE]for v in np.argsort((step_matrix).flatten())[::-1]])

def process_fit_dictionary(dictionary,trace,step_matrix):
    for d in dictionary:
        num = dictionary[d]
        step_matrix[d[0]] -= num
        step_matrix[d[1]] += num
        reg_id_1 = d[0][0]+SIZE * d[0][1] + 1
        reg_id_2 = d[1][0]+SIZE * d[1][1] + 1
        reg_index = np.array([])
        if len(np.where(trace==reg_id_1)[0])!=0:
            reg_index=np.random.choice(np.where(trace==reg_id_1)[0],int(num),replace = False)
        for index in reg_index:
            trace[index] = reg_id_2
    return [trace,step_matrix]

#有用性の計算
def yuuyousei(data,new_data):
    yuuyousei = 0
    for i in range(len(data)):
        for j in range(len(data[0])):
            x1 = int((data[i,j]-1)/32)
            y1 = (data[i,j]-1)%32
            x2 = int((new_data[i,j]-1)/32)
            y2 = (new_data[i,j]-1)%32
            distance = math.sqrt(((x1-x2)*0.34125)**2+((y1-y2)*0.346875)**2)
            if distance>2:
                distance=2
            yuuyousei += 1-0.5*distance
    return yuuyousei/(len(data)*NUMBER_OF_TIME)

def process_mean_01(org_trace,distribution,cluster):
    num_of_cluster = int(max(cluster))
    trace = copy.copy(org_trace)
    for i in trange(num_of_cluster+1):
        num = 0
        trace_01 = copy.copy(trace[cluster==i])
        dist_01 = distribution[cluster==i]
        org_trace_01 = org_trace[cluster==i]
        step_matrixes_01 = np.array([process_make_step_matrix(d) for d in dist_01])
        mean_step_matrix_01 = process_make_mean_step_matrix(step_matrixes_01)
        sort_index = process_sort_index(mean_step_matrix_01)
        if len(trace_01) > 1:
            while yuuyousei(org_trace_01,trace_01)>=0.7 and num < NUMBER_OF_TIME:
                trace[cluster==i] = copy.copy(trace_01)
                dict_01 = otani_method2.otani_method2(step_matrixes_01,mean_step_matrix_01,sort_index[num,0],sort_index[num,1])
                for j in range(len(trace_01)):  
                    trace_01[j],step_matrixes_01[j]=process_fit_dictionary(dict_01[j],trace_01[j],step_matrixes_01[j])
                num += 1
    return trace


def process_mean_02(org_trace,org_trace_2,distribution,org_distribution,cluster):
    num_of_cluster = int(max(cluster))
    trace = copy.copy(org_trace)
    for i in trange(num_of_cluster+1):
        num = 0
        trace_01 = copy.copy(trace[cluster==i])
        dist_01 = distribution[cluster==i]
        dist_02 = org_distribution[cluster==i]
        org_trace_01 = org_trace_2[cluster==i]
        step_matrixes_01 = np.array([process_make_step_matrix(d) for d in dist_01])
        step_matrixes_02 = np.array([process_make_step_matrix(d) for d in dist_02])
        mean_step_matrix_01 = process_make_mean_step_matrix(step_matrixes_02)
        sort_index = process_sort_index(mean_step_matrix_01)
        if len(trace_01) > 1:
            while yuuyousei(org_trace_01,trace_01)>=0.7 and num < NUMBER_OF_TIME:
                trace[cluster==i] = copy.copy(trace_01)
                dict_01 = otani_method2.otani_method2(step_matrixes_01,mean_step_matrix_01,sort_index[num,0],sort_index[num,1])
                for j in range(len(trace_01)):  
                    trace_01[j],step_matrixes_01[j]=process_fit_dictionary(dict_01[j],trace_01[j],step_matrixes_01[j])
                num += 1
    return trace


def process_mean_03(org_trace,distribution,cluster,yuyo):
    num_of_cluster = int(max(cluster))
    trace = copy.copy(org_trace)
    for i in trange(num_of_cluster+1):
        num = 0
        trace_01 = copy.copy(trace[cluster==i])
        dist_01 = distribution[cluster==i]
        org_trace_01 = org_trace[cluster==i]
        step_matrixes_01 = np.array([process_make_step_matrix(d) for d in dist_01])
        mean_step_matrix_01 = process_make_mean_step_matrix(step_matrixes_01)
        sort_index = process_sort_index(mean_step_matrix_01)
        if len(trace_01) > 1:
            while yuuyousei(org_trace_01,trace_01)>=yuyo and num < NUMBER_OF_TIME:
                trace[cluster==i] = copy.copy(trace_01)
                dict_01 = otani_method2.otani_method2(step_matrixes_01,mean_step_matrix_01,sort_index[num,0],sort_index[num,1])
                for j in range(len(trace_01)):  
                    trace_01[j],step_matrixes_01[j]=process_fit_dictionary(dict_01[j],trace_01[j],step_matrixes_01[j])
                num += 1
    return trace
