#!/usr/bin/env python3
"""
Created by Makoto Iguchi on Oct 3, 2019 (last updated: Sep 17, 2021)

Description: 
    ID-disclosure (re-identification) attack based on fuzzy "TF-IDF" visit-probability vectors

Usage:
    IF-FuzzyVisitProb.py [Reference Trace (in)] [Anonymized Trace (in)] [Estimated Table (out)] [n0 (deault: 0.33)] [r (default:0.5)] [fuzzy_range (default:1)]
"""
import numpy as np
import math
import csv
import sys

from scipy import spatial

def tfidf(vectors):

    # Calculate IDF
    # IDF weight is fixed to 1, so there is no code.

    '''
    # Calculate IDF 
    ## The following IDF weight log U/u_r didn't work well... 
    idf = np.zeros(num_region)
    for i in range(num_region):
        if np.count_nonzero(vectors[:,i] > 0) == 0:
            idf[i] = 0
        else:
            idf[i] = math.log(num_user / np.count_nonzero(vectors[:,i] > 0))
    '''

    # Calculate TF
    ## Logarithmically scaled frequency 
    vf = np.vectorize(lambda x: math.log(x + 1)) # logarithmic term frequency
    vectors = vf(vectors)

    #return vectors * idf     # Return "TF-IDF"ed vectors
    return vectors # Return TF only since IDF is fixed to 1

# return x and y for a given region_id
def get_coordinates(region_id):
    x = region_id % 32
    y = int(region_id / 32)
    return x, y
    
# "Fuzzificate" the vector
def fuzzificate(vectors, fuzzy_range):
    fuzzy_vectors = np.zeros((num_user, num_region))

    for user_id in range(num_user):
        for reg_id in range(num_region):
            if vectors[user_id][reg_id] == 0:
               continue
            reg_id_x, reg_id_y = get_coordinates(reg_id)
            lower_x, upper_x = max(0, reg_id_x - fuzzy_range), min(31, reg_id_x + fuzzy_range)
            lower_y, upper_y = max(0, reg_id_y - fuzzy_range), min(31, reg_id_y + fuzzy_range)
            for x in range(lower_x, upper_x + 1):
                for y in range(lower_y, upper_y + 1):
                    # Fuzzificate the visit probability vectors by applying the exponential decay
                    dist = np.sqrt((x - reg_id_x) ** 2 + (y - reg_id_y) ** 2)
                    fuzzy_vectors[user_id][y * 32 + x] +=  vectors[user_id][reg_id] * n0 * (math.e ** (-dist * r))

    # Return fuzzificated vectors
    return fuzzy_vectors

# Number of users
num_user = 2000
# Number of regions on the x-axis
num_region_x = 32
# Number of regions on the y-axis
num_region_y = 32
# Number of regions on the y-axis
num_region = num_region_x * num_region_y
# Number of days in each trace sets
num_day = 20

ref_trace_file = sys.argv[1] # Reference trace file (input)
ano_trace_file = sys.argv[2] # Anonymized trace file (input)
inf_id_table = sys.argv[3] # Estimated table file (output)

n0 = 0.33 # Initial n_0 
if len(sys.argv) >= 5:
    n0 = float(sys.argv[4])

r = 0.5 # Initial decaly rate r 
if len(sys.argv) >= 6:
    r = float(sys.argv[5])

fuzzy_range = 1 # Fuzzy range
if len(sys.argv) >= 7:
    fuzzy_range = int(sys.argv[6])

##### Train a "TF-IDF" probability vectors #####
ref_visit_vectors = np.zeros((num_user, num_region))
f = open(ref_trace_file, "r")
reader = csv.reader(f)
next(reader)

# Read a reference trace set
for lst in reader:
    user_id = int(lst[0])-1
    reg_id = int(lst[2])-1
    ref_visit_vectors[user_id][reg_id] += 1
f.close()

ref_visit_vectors = tfidf(ref_visit_vectors) # Genarate TF-IDF style feature vector

if fuzzy_range > 0:
    ref_visit_vectors = fuzzificate(ref_visit_vectors, fuzzy_range) # Generate fuzzy feature vector 

##### Re-identify ##### 
anon_visit_vectors = np.zeros((num_user, num_region_x * num_region_y))

# Read a public anonymized trace set
f = open(ano_trace_file, "r")
reader = csv.reader(f)
next(reader)

##Create visit probability vector for each pseudo_id
for lst in reader:
    pseudo_id = int(lst[0])- num_user - 1
    reg_id_lst = lst[2].split(" ")
    
    reg_id_len = len(reg_id_lst)
    if reg_id_len == 1 and reg_id_lst[0] != "*":
        reg_id = int(reg_id_lst[0]) - 1
        anon_visit_vectors[pseudo_id][reg_id] += 1
        
    elif reg_id_len >=2:
        score = 1/reg_id_len
        for reg_id in reg_id_lst:
            anon_visit_vectors[pseudo_id][int(reg_id) - 1] += score
f.close()

anon_visit_vectors = tfidf(anon_visit_vectors)

# Find the nearest user_id for each pseudo_id
tree = spatial.cKDTree(ref_visit_vectors)
result = tree.query(anon_visit_vectors)

##### Output an inferred ID table #####
g = open(inf_id_table, "w")
print("user_id", file=g)
writer = csv.writer(g, lineterminator="\n")
for user_id in result[1]:
    lst = [user_id + 1]
    writer.writerow(lst)
g.close()