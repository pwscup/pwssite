#!/usr/bin/env python3
"""
Created by Makoto Iguchi on Oct 3, 2019 (last update Sep 17, 2021)

Description: 
    Trace inference attack with the "swapping frequent regions" strategy
    
Usage:
    TS-SwapFrequentRegions.py [Reference Trace Set (in)] [Public Anonymized Trace Set (in)]
    [Inferred ID table (in)][Inferred Trace Set (out)][Threshold (in)]

"""
import sys
import csv
import random
import numpy as np
from collections import Counter

if len(sys.argv) < 6:
    print("Usage:",sys.argv[0],"[Reference Trace Set (in)] [Public Anonymized Trace Set (in)] [Inferred ID table (in)][Inferred Trace Set (out)] [threshold (in)]")
    sys.exit(0)

ref_trace_set = sys.argv[1]
anon_trace_set = sys.argv[2]
inf_id_table = sys.argv[3]
inf_trace_set = sys.argv[4]
threshold = int(sys.argv[5])

num_users = 2000
num_time = 20
num_days = 20

# Create a mapping table (PseudoID and UserID)
mapping = [-1 for _ in range(num_users)]
pool = []

f = open(inf_id_table, "r") # Read an inferred ID table
next(f)
for pseudo_id, user_id in enumerate(f):
  if mapping[int(user_id) - 1] == -1:
    mapping[int(user_id) - 1] = pseudo_id
  else:
    pool.append(pseudo_id)
f.close()

#雑に重複処理
random.shuffle(pool)
for i in range(num_users): 
  if mapping[i] == -1:
    mapping[i] = int(pool.pop())

# Read Public anonymized trace set
anonymous_trace_set = [["" for i in range(num_time * num_days)] for j in range(num_users)]
f = open(anon_trace_set, "r")
reader = csv.reader(f)
next(f)
for lst in reader:
  pseudo_id = int(lst[0]) - num_users - 1 
  time_id = int(lst[1]) - num_time * num_days - 1
  anonymous_trace_set[pseudo_id][time_id] = lst[2]
f.close()

# Read Reference trace set
regions = [[[] for _ in range(num_time)] for _ in range(num_users)]
f = open(ref_trace_set, "r")
reader = csv.reader(f)
next(reader) # skip header  
for lst in reader:
    user_id = int(lst[0]) - 1
    time_id = int(lst[1]) - 1
    reg_id = int(lst[2])
    regions[user_id][time_id % num_time].append(reg_id)
f.close()

# Write Inferred trace set
g = open(inf_trace_set, "w")
print("reg_id", file=g)
writer = csv.writer(g, lineterminator="\n")

for user_id in range(num_users):
  for time_id in range(num_days * num_time):
    pseudo_id = mapping[user_id]
    reg_id = anonymous_trace_set[pseudo_id][time_id].split(" ")

    # Pick up the most frequent region in the reference trace set
    freq_reg_id, freq_count = Counter(regions[user_id][time_id % num_time]).most_common()[0]

    if int(freq_count) >= threshold:
      lst = [int(freq_reg_id)] # Swap with the most frequent region 
    elif reg_id[0] == "*":
      lst = [int(freq_reg_id)] # Swap with the most frequent region if the region is deleted
    elif len(reg_id) > 1:
      lst = [int(random.choice(reg_id))] # Random pickup
    else:
      # As is
      lst = [int(reg_id[0])]
    writer.writerow(lst)
g.close()